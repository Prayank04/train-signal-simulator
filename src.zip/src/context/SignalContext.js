import React, { createContext, useContext, useState, useCallback } from 'react';

const SignalContext = createContext();

export function SignalProvider({ children }) {
  const [signalStates, setSignalStates] = useState({});

  const processLogLine = useCallback((line) => {
    console.log("📥 [Signal] Processing:", line);

    // Capture the tag (e.g. "S1", "A3103", "S1HR_F", etc.) and the ECR suffix
    const m = line.match(
      /Equ\.:\s*([A-Za-z0-9_]+?)(RECR|HECR|HHECR|DECR)\s*Change\s*:\s*0-+>1/i
    );
    if (!m) return;

    const [, tag, suffix] = m;
    let color;

    switch (suffix.toUpperCase()) {
      case "RECR":
        color = "R";
        console.log(`🔴 [Signal] ${tag} → ${color}`);
        break;
      case "HECR":
        color = "Y";
        console.log(`🟡 [Signal] ${tag} → ${color}`);
        break;
      case "HHECR":
        color = "YY";
        console.log(`🟡🟡 [Signal] ${tag} → ${color}`);
        break;
      case "DECR":
        color = "G";
        console.log(`🟢 [Signal] ${tag} → ${color}`);
        break;
      default:
        return;
    }

    setSignalStates(prev => ({
      ...prev,
      [tag]: color
    }));
  }, []);

  const resetSignals = useCallback(() => {
    console.log("♻️ [Signal] Resetting all signals to default");
    setSignalStates({});
  }, []);

  return (
    <SignalContext.Provider value={{
      signalStates,
      processLogLine,
      resetSignals
    }}>
      {children}
    </SignalContext.Provider>
  );
}

export const useSignalContext = () => {
  const ctx = useContext(SignalContext);
  if (!ctx) {
    throw new Error("useSignalContext must be used within a SignalProvider");
  }
  return ctx;
};
