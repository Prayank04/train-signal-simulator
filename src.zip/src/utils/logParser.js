// src/utils/logParser.js
const MONTHS = {
  Jan:0,Feb:1,Mar:2,Apr:3,May:4,Jun:5,
  Jul:6,Aug:7,Sep:8,Oct:9,Nov:10,Dec:11
};

export function parseLogFile(text) {
  const lines = text.split(/\r?\n/).map(l=>l.trim());

  // Find initialTime same as before...
  const fromLine = lines.find(l=>l.startsWith("From"));
  if (!fromLine) throw new Error('No "From ..."');
  const fromMatch = fromLine.match(
    /From\s+(\d{2})-([A-Za-z]{3})-(\d{4})\s+(\d{2}):(\d{2}):(\d{2})/
  );
  if (!fromMatch) throw new Error("Bad From");
  const [,DD,Mon,YYYY,hh,mm,ss] = fromMatch;
  const initialTime = new Date(
    +YYYY, MONTHS[Mon], +DD, +hh, +mm, +ss
  );

  // Now build full entries
  const entryBlocks = [];
  let current = null;
  const tsLineRx = /^\d{2}\/[A-Za-z]{3}\/\d{4}\s+\d{2}:\d{2}:\d{2}\.\d{3}/;

  for (const line of lines) {
    if (tsLineRx.test(line)) {
      // start a brand‑new block
      current = [line];
      entryBlocks.push(current);
    } else if (current) {
      // continuation of the previous block
      if (line) current.push(line);
    }
  }

  // turn each block into a {time, raw}
  const allLogEntries = entryBlocks.map(block => {
    const full = block.join(' ');
    const m = full.match(/^(\d{2})\/([A-Za-z]{3})\/(\d{4}) (\d{2}):(\d{2}):(\d{2})\.(\d{3})/);
    const [,dD,mMon,yY,hH,mM,sS,mMM] = m;
    const time = new Date(
      +yY, MONTHS[mMon], +dD,
      +hH, +mM, +sS, +mMM
    );
    return { time, raw: full };
  });

  return { initialTime, allLogEntries };
}

