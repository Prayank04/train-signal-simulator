import React, { useEffect, useState } from 'react';
import { getAllSignals, resetSignals } from '../../utils/api';

export default function SignalPanel() {
  const [signals, setSignals] = useState({});

  const fetchSignals = async () => {
    try {
      const data = await getAllSignals();
      setSignals(data);
    } catch {}
  };

  useEffect(() => {
    fetchSignals();
    // Optionally poll every few seconds:
    const interval = setInterval(fetchSignals, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleReset = async () => {
    await resetSignals();
    fetchSignals();
  };

  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold">Signal States</h2>
      <button
        onClick={handleReset}
        className="mt-2 mb-4 px-3 py-1 bg-red-500 text-white rounded"
      >Reset Signals</button>
      <div className="grid grid-cols-2 gap-2">
        {Object.entries(signals).map(([sid, info]) => (
          <div key={sid} className="p-2 border rounded flex justify-between">
            <span>{sid}</span>
            <span className="font-mono">{info.aspect} ({info.color})</span>
          </div>
        ))}
        {Object.keys(signals).length === 0 && <p>No signals yet.</p>}
      </div>
    </div>
  );
}