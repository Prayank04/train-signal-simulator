import React from 'react';
import './ControlButton.css';

const ControlButton = ({ 
  label, 
  active = false, 
  color = 'gray', 
  size = 'normal',
  onClick,
  className = '',
  disabled = false 
}) => {
  const handleClick = () => {
    if (!disabled && onClick) {
      onClick();
    }
  };

  return (
    <button
      className={`control-button ${color} ${active ? 'active' : ''} ${size} ${className} ${disabled ? 'disabled' : ''}`}
      onClick={handleClick}
      disabled={disabled}
    >
      {label}
    </button>
  );
};

export default ControlButton;