import React from 'react';

const RightBottomTrackLayout = () => {
  const spacing = 80; // Distance between signals
  const circleRadius = 4;
  // Matching the left bottom track layout dimensions
  const lineY1 = 35;  // Top line (same as left)
  const lineY2 = 55;  // Second line (same as left)
  const lineY3 = 75;  // Third line (same as left)
  const lineY4 = 95;  // Bottom line (same as left)
  const startX = 20;  // Starting X position (adjusted for right side)
  const signalOffsetY = 12;

  // Signal data for each line (right side)
  const line1Signals = [
    'A3112', 'A3110'
  ];

  const line2Signals = [
    '3112XT', '3110XT'
  ];

  const line3Signals = [
    '3103XT', '3101XT'
  ];

  const line4Signals = [
    'A3103', 'A3105'
  ];

  // ALH label
  const alhLabel = 'ALH-058';

  // Render DN signal (T-shape first, then A circle, then 4 circles) - flipped version
  const renderDNSignalFlipped = (signalName, x, y, fillPattern = [false, false, false, false]) => {
    const circles = [];
    const signalSpacing = 10;
    
    // 4 circles starting after the single circle and horizontal line
    const circlesStartX = x + 25; // Start circles after T-shape and single circle
    for (let i = 0; i < 4; i++) {
      circles.push(
        <circle
          key={`${signalName}-${i}`}
          cx={circlesStartX + i * signalSpacing}
          cy={y}
          r={circleRadius}
          fill={fillPattern[i] ? "green" : "none"}
          stroke="white"
          strokeWidth="1"
        />
      );
    }

    // T-shape at the beginning
    const tHorizStartX = x;
    const tHorizEndX = x + 3;
    const tVertX = (tHorizStartX + tHorizEndX) / 2;
    const tVertYTop = y - 5;
    const tVertYBottom = y + 5;
    
    // Single circle with A - attached to T-shape
    const singleCircleX = tHorizEndX + circleRadius; // Position circle right after T-shape
    
    // Horizontal line connecting A circle to 4 circles
    const lineStartX = singleCircleX + circleRadius; // Start from A circle edge
    const lineEndX = circlesStartX - circleRadius;

    return (
      <g key={signalName}>
        {/* T-shape first */}
        <line x1={tHorizStartX} y1={y} x2={tHorizEndX} y2={y} stroke="white" strokeWidth="1" />
        <line x1={tVertX} y1={tVertYTop} x2={tVertX} y2={tVertYBottom} stroke="white" strokeWidth="1" />
        
        {/* Single circle with A - attached to T-shape */}
        <circle cx={singleCircleX} cy={y} r={circleRadius} fill="none" stroke="white" strokeWidth="1" />
        <text x={singleCircleX} y={y + 2} fill="white" fontSize="6" fontFamily="Arial" fontWeight="bold" textAnchor="middle">A</text>
        
        {/* Horizontal line connecting A circle to 4 circles */}
        <line x1={lineStartX} y1={y} x2={lineEndX} y2={y} stroke="white" strokeWidth="1" />
        
        {/* 4 circles */}
        {circles}
        
        <text x={x + 15} y={y - 12} fill="#00bfff" fontSize="8">{signalName}</text>
      </g>
    );
  };

  // Render signal with circles, T-shape and A circle (for A signals)
  const renderSignalWithA = (signalName, x, y, fillPattern = [false, false, false, false]) => {
    const circles = [];
    const signalSpacing = 10;
    
    for (let i = 0; i < 4; i++) {
      circles.push(
        <circle
          key={`${signalName}-${i}`}
          cx={x + i * signalSpacing}
          cy={y}
          r={circleRadius}
          fill={fillPattern[i] ? "green" : "none"}
          stroke="white"
          strokeWidth="1"
        />
      );
    }

    const x4 = x + 3 * signalSpacing;
    const x5 = x4 + signalSpacing + 8;
    const tHorizStartX = x5 + circleRadius;
    const tHorizEndX = tHorizStartX + 3;
    const tVertX = (tHorizStartX + tHorizEndX) / 2;
    const tVertYTop = y - 5;
    const tVertYBottom = y + 5;

    return (
      <g key={signalName}>
        {circles}
        <line x1={x4 + circleRadius} y1={y} x2={x5 - circleRadius} y2={y} stroke="white" strokeWidth="1" />
        <circle cx={x5} cy={y} r={circleRadius} fill="none" stroke="white" strokeWidth="1" />
        <text x={x5} y={y + 2} fill="white" fontSize="6" fontFamily="Arial" fontWeight="bold" textAnchor="middle">A</text>
        <line x1={x5 + circleRadius} y1={y} x2={x5 + circleRadius + 3} y2={y} stroke="white" strokeWidth="1" />
        <line x1={tVertX} y1={tVertYTop} x2={tVertX} y2={tVertYBottom} stroke="white" strokeWidth="1" />
        
        <text x={x} y={y + 25} fill="#00bfff" fontSize="8">{signalName}</text>
      </g>
    );
  };

  return (
    <div className="right-side-track-layout" style={{ 
      marginTop: '-185px', // Moved down further to align with left bottom track level
      marginLeft: '1150px', // Keep the gap between left and right bottom track
      position: 'absolute'
    }}>
      <svg width="220" height="180" style={{ backgroundColor: "#333333" }}>
        
        {/* Four horizontal track lines - extended much more on both sides */}
        <line x1={-30} y1={lineY1} x2={220} y2={lineY1} stroke="white" strokeWidth="3" />
        <line x1={-30} y1={lineY2} x2={220} y2={lineY2} stroke="white" strokeWidth="3" />
        <line x1={-30} y1={lineY3} x2={220} y2={lineY3} stroke="white" strokeWidth="3" />
        <line x1={-30} y1={lineY4} x2={220} y2={lineY4} stroke="white" strokeWidth="3" />

        {/* Line 1 Signals (A3112, A3110) - aligned with vertical line pairs */}
        {line1Signals.map((signal, index) => {
          const fillPattern = [false, true, false, false];
          // Position signals to align with vertical line pairs: 82,90 and 152,160
          const signalX = index === 0 ? 80 : 150; // First signal at 62, second at 132
          return renderDNSignalFlipped(signal, signalX, lineY1 - signalOffsetY, fillPattern);
        })}

        {/* Line 1 XT Labels positioned like left track */}
        <text x={40} y={lineY1 + 8} fill="#00bfff" fontSize="7" textAnchor="middle">3114XT</text>
        <text x={110} y={lineY1 + 8} fill="#00bfff" fontSize="7" textAnchor="middle">3112XT</text>
        <text x={190} y={lineY1 + 8} fill="#00bfff" fontSize="7" textAnchor="middle">3110XT</text>

        {/* Line 4 Signals (A3103, A3105) - aligned with vertical line pairs */}
        {line4Signals.map((signal, index) => {
          const fillPattern = signal === 'A3103' ? [true, false, false, true] : [false, true, false, false];
          // Position signals to align with vertical line pairs: 62,79 and 142,159
          const signalX = index === 0 ? 18 : 98; // First signal at 42, second at 122
          return renderSignalWithA(signal, signalX, lineY4 + signalOffsetY, fillPattern);
        })}

        {/* Line 4 XT Labels positioned like left track */}
        <text x={40} y={lineY4 - 8} fill="#00bfff" fontSize="7" textAnchor="middle">3103XT</text>
        <text x={140} y={lineY4 - 8} fill="#00bfff" fontSize="7" textAnchor="middle">3105XT</text>

        {/* Vertical lines on Line 1 - matching left track pattern */}
        {[82, 90, 152, 160].map((xPos, index) => (
          <line
            key={`line1-marker-${index}`}
            x1={xPos}
            y1={lineY1 - 6}
            x2={xPos}
            y2={lineY1 + 6}
            stroke="white"
            strokeWidth="2"
          />
        ))}

        {/* Vertical lines on Line 2 - matching left track pattern */}
        {[82, 90].map((xPos, index) => (
          <line
            key={`line2-marker-${index}`}
            x1={xPos}
            y1={lineY2 - 6}
            x2={xPos}
            y2={lineY2 + 6}
            stroke="white"
            strokeWidth="2"
          />
        ))}

        {/* Line 2 XT Labels */}
        <text x={150} y={lineY2 - 6} fill="#00bfff" fontSize="7" textAnchor="middle">3112XT_3110XT</text>
        <text x={40} y={lineY2 - 6} fill="#00bfff" fontSize="7" textAnchor="middle">2AXT_3114XT</text>


        {/* Vertical lines on Line 3 - matching left track pattern */}
        {[62, 70].map((xPos, index) => (
          <line
            key={`line3-marker-${index}`}
            x1={xPos}
            y1={lineY3 - 6}
            x2={xPos}
            y2={lineY3 + 6}
            stroke="white"
            strokeWidth="2"
          />
        ))}

        {/* Line 3 XT Labels */}
        <text x={30} y={lineY3 - 8} fill="#00bfff" fontSize="7" textAnchor="middle">3103XT_3101XT</text>
        

        {/* Vertical lines on Line 4 - matching left track pattern */}
        {[62, 70, 142, 150].map((xPos, index) => (
          <line
            key={`line4-marker-${index}`}
            x1={xPos}
            y1={lineY4 - 6}
            x2={xPos}
            y2={lineY4 + 6}
            stroke="white"
            strokeWidth="2"
          />
        ))}
      </svg>
    </div>
  );
};

export default RightBottomTrackLayout;