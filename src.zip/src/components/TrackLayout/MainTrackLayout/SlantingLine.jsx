import React from "react";

const SlantingLine = ({
  Upx,
  Dnx,
  Upy,
  Dny,
  stroke = "white",
  strokeWidth = 2,
  circleRadius = 3,
  circleFill = "#333333",
  circleStroke = "white",
  circleStrokeWidth = 0.5,
  showPerpendicular = true,
  perpendicularLength = 10
}) => {
  // Line endpoints
  const x1 = Upx;
  const x2 = Dnx;
  const y1 = Upy + 7;
  const y2 = Dny - 7;

  // Slope of main line
  const m = (y2 - y1) / (x2 - x1);
  const xshift = m > 0 ? 4 : m < 0 ? -4 : 0;

  // Midpoint
  const midX = (x1 + x2) / 2;
  const midY = (y1 + y2) / 2;

  // Perpendicular line for styling
  const perpSlope = -1 / m;
  const length = perpendicularLength;
  const denominator = Math.sqrt(1 + perpSlope ** 2);

  const perpX1 = midX + (length / 2) * (1 / denominator);
  const perpY1 = midY + (length / 2) * (perpSlope / denominator);
  const perpX2 = midX - (length / 2) * (1 / denominator);
  const perpY2 = midY - (length / 2) * (perpSlope / denominator);

  return (
    <g>
      {/* Main slanting line */}
      <line 
        x1={x1} 
        y1={y1} 
        x2={x2} 
        y2={y2} 
        stroke={stroke} 
        strokeWidth={strokeWidth} 
      />

      {/* Optional perpendicular styling line */}
      {showPerpendicular && (
        <line
          x1={perpX1}
          y1={perpY1}
          x2={perpX2}
          y2={perpY2}
          stroke={stroke}
          strokeWidth={strokeWidth / 2}
        />
      )}

      {/* Shifted upper circle */}
      <circle
        cx={Upx + xshift}
        cy={Upy - 15}
        r={circleRadius}
        fill={circleFill}
        stroke={circleStroke}
        strokeWidth={circleStrokeWidth}
      />

      {/* Shifted lower circle */}
      <circle
        cx={Dnx - xshift}
        cy={Dny + 15}
        r={circleRadius}
        fill={circleFill}
        stroke={circleStroke}
        strokeWidth={circleStrokeWidth}
      />
{/* 
      <line 
        x1={Upx + xshift -1.5} 
        y1={Upy-10} 
        x2={x1} 
        y2={y1 - 10} 
        stroke={stroke} 
        strokeWidth={strokeWidth/3} 
      />

      <line 
        x1={x1} 
        y1={y1} 
        x2={x2} 
        y2={y2} 
        stroke={stroke} 
        strokeWidth={strokeWidth/2} 
      />

      <line 
        x1={x1} 
        y1={y1} 
        x2={x2} 
        y2={y2} 
        stroke={stroke} 
        strokeWidth={strokeWidth/2}  
      />*/}
    </g>
  );
};

export default SlantingLine;
