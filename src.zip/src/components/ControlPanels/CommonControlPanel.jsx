import React, { useState } from 'react';
import { TRACK_LAYOUT_CONSTANTS } from '../../utils/constants';

const CommonControlPanel = () => {
  // State for button controls
  const [buttonStates, setButtonStates] = useState({
    // Left Side
    topLeftCnln: false,
    bottomLeftMind: false,
    bottomLeftComplex: false,
    
    // Right Side
    topRightHprn: false,
    topRightComplex: false,
    bottomRightCnln: false
  });

  const toggleButton = (buttonName) => {
    setButtonStates(prev => ({
      ...prev,
      [buttonName]: !prev[buttonName]
    }));
  };

  // Simple circle button
  const SimpleButton = ({ name, isActive }) => {
    return (
      <button
        onClick={() => toggleButton(name)}
        style={{
          width: '12px',
          height: '12px',
          borderRadius: '50%',
          border: '1px solid white',
          backgroundColor: isActive ? '#facc15' : 'transparent',
          cursor: 'pointer'
        }}
      />
    );
  };

  // Complex button (white with black center)
  const ComplexButton = ({ name, isActive }) => {
    return (
      <button
        onClick={() => toggleButton(name)}
        style={{
          position: 'relative',
          width: '14px',
          height: '14px',
          cursor: 'pointer',
          backgroundColor: 'transparent',
          border: 'none'
        }}
      >
        <div style={{
          width: '14px',
          height: '14px',
          borderRadius: '50%',
          backgroundColor: 'white',
          border: '1px solid #9ca3af'
        }}></div>
        <div style={{
          position: 'absolute',
          top: '3px',
          left: '3px',
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          backgroundColor: 'black'
        }}></div>
      </button>
    );
  };

  const boxStyle = {
    border: '2px solid #9ca3af',
    backgroundColor: '#333333',
    padding: '8px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    minHeight: '80px', // Increased height for bottom block
    minWidth: '80px'
  };

  const labelStyle = {
    color: '#22d3ee',
    fontSize: '8px',
    fontWeight: 'bold',
    textAlign: 'center',
    margin: '2px 0'
  };

  const arrowStyle = {
    color: '#22d3ee',
    fontSize: '12px',
    fontWeight: 'bold'
  };




  return (
    <>
      
        {/* Block Near Down Loop Line - Left Side */}
        <div style={{
          position: 'absolute',
          top: TRACK_LAYOUT_CONSTANTS.dnLoopLineY+165, // Positioned near the down loop line in main track
          left: '10px', // Moved closer to the track area
          zIndex: 1000,
          transform: 'scale(0.8)'
        }}>
          <div style={boxStyle}>
            <div style={labelStyle}>CNLN<br/>LVV</div>
            <SimpleButton name="topLeftCnln" isActive={buttonStates.topLeftCnln} />
            <div style={{...arrowStyle, marginTop: '4px'}}>→</div>
            <div style={labelStyle}>DN LINE</div>
          </div>
        </div>

        {/* Block Near Up Loop Line - Left Side */}
        <div style={{
          position: 'absolute',
          top: TRACK_LAYOUT_CONSTANTS.upLoopLineY+220, // Positioned near the up loop line in main track
          left: '10px', // Moved closer to the track area
          zIndex: 1000,
          transform: 'scale(0.8)'
        }}>
          <div style={boxStyle}>
            <div style={labelStyle}>MIND<br/>LVV</div>
            <SimpleButton name="bottomLeftMind" isActive={buttonStates.bottomLeftMind} />
            <div style={labelStyle}>MIND<br/>RESET</div>
            <ComplexButton name="bottomLeftComplex" isActive={buttonStates.bottomLeftComplex} />
            <div style={{...arrowStyle, marginTop: '4px'}}>←</div>
            <div style={labelStyle}>UP LINE</div>
          </div>
        </div>

        {/* Block Near Down Loop Line - Right Side */}
        <div style={{
          position: 'absolute',
          top: TRACK_LAYOUT_CONSTANTS.dnLoopLineY+140, // Positioned near the down loop line in main track
          right: '10px', // Right side positioning
          zIndex: 1000,
          transform: 'scale(0.8)'
        }}>
          <div style={boxStyle}>
            <div style={labelStyle}>HPRN<br/>LVV</div>
            <SimpleButton name="topRightHprn" isActive={buttonStates.topRightHprn} />
            <div style={labelStyle}>HPRN<br/>RESET</div>
            <ComplexButton name="topRightComplex" isActive={buttonStates.topRightComplex} />
            <div style={{...arrowStyle, marginTop: '4px'}}>→</div>
            <div style={labelStyle}>DN LINE</div>
          </div>
        </div>

        {/* Block Near Up Loop Line - Right Side */}
        <div style={{
          position: 'absolute',
          top: TRACK_LAYOUT_CONSTANTS.upLoopLineY+220, // Positioned near the up loop line in main track
          right: '10px', // Right side positioning
          zIndex: 1000,
          transform: 'scale(0.8)'
        }}>
          <div style={boxStyle}>
            <div style={labelStyle}>CNLN<br/>LVV</div>
            <SimpleButton name="bottomRightCnln" isActive={buttonStates.bottomRightCnln} />
            <div style={{...arrowStyle, marginTop: '4px'}}>←</div>
            <div style={labelStyle}>UP LINE</div>
          </div>
        </div>
    </>
  );
};

export default CommonControlPanel;